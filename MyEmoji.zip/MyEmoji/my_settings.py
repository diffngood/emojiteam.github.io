DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.mysql",
        "NAME": "emojis_db",
        "USER": "kwb",
        "PASSWORD": "0000",
        "HOST": "localhost",
        "PORT": "3306",
    }
}
SECRET_KEY = "django-insecure-x7tzy4(-4bj$hlf40tq+rk4w=^pc_vr$c*yy7)s5gypa&s^88i"
# SECRET_KEY = "django-insecure-%4q1jlt5)_5jh!8t*g#z9=u#@!2l+5i2!_jueemek5r4vd(9+_"
